<html>

<head>
    <meta chatset="UTF-8">
    <link rel="stylesheet" type="text/css" href="styleLogin.css" media="screen" />

</head>

<body>
    <div class="bg"></div>
    <div class="bg bg2"></div>
    <div class="bg bg3"></div>
    <?php
//header("refresh:8");

$servername = "remotemysql.com";
$port = 3306;
$dbname = "1drERJSalO";
$username = "1drERJSalO";
$password = "wVDjZFTqcT";
$memoryMinLimit = 3;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if (mysqli_connect_error()) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Logica de mi aplicacion:
$sql = "SELECT * FROM Users";
$result = $conn->query($sql);
$user = $result->fetch_object();

// Cierre de conexión o superaremos el límite
//$conn->close();

function login($id, $conn)
{
    $sql = "UPDATE Users SET IsAuthenticated = 'True' WHERE User = '$id'";
    $conn->query($sql);
    $conn->close();
}
function disconnect($id, $conn)
{
    $sql = "UPDATE Users SET IsAuthenticated = 'False' WHERE User = '$id'";
    $conn->query($sql);
    $conn->close();
}


if (array_key_exists('username', $_POST)) {

    if ((($user->User) == $username = $_POST['username']) && (($user->Password) == $password = $_POST['password'])) {
        header("Location: http://localhost/tfg/ITService.php");
        login($user->User, $conn);
        die();
    }
}

disconnect($user->User, $conn);


?>

    <form method="POST">
        <div id="login-box">
            <h1>Login</h1>
            <! - El título de Inicio de sesión ->

                <div class="form">
                    <div class="item">
                        <! - parte de nombre de usuario ->
                            <i></i>
                            <! - Se utilizará para dibujar el icono delante del nombre de usuario ->
                                <input type="text" placeholder="username" name="username">
                                <! - Entrada de nombre de usuario realizada por cuadro de texto ->
                    </div>

                    <div class="item">
                        <! - parte de la contraseña ->
                            <i></i>
                            <! - Se utilizará para dibujar el icono delante de la contraseña en el futuro ->
                                <input type="password" placeholder="password" name="password">
                                <! - Entrada de contraseña usando el cuadro de texto de contraseña ->
                    </div>

                </div>
                <br>
                <button class="ov-btn-grow-box" type="submit">Login</button>
                <! - Botón de inicio de sesión implementado con el botón ->
        </div>
    </form>
</body>

</html>