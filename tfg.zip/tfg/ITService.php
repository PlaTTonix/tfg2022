<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
	<script src="https://kit.fontawesome.com/fe6e9dde8e.js" crossorigin="anonymous"></script>
	<title>IT-Home</title>
</head>

<body>

<div class="bg"></div>
<div class="bg bg2"></div>
<div class="bg bg3"></div>
	<?php
    //header("refresh:8");
    
    $servername = "remotemysql.com";
    $port = 3306;
    $dbname = "1drERJSalO";
    $username = "1drERJSalO";
    $password = "wVDjZFTqcT";
    $memoryMinLimit = 3;

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if (mysqli_connect_error()) {
	    die("Database connection failed: " . mysqli_connect_error());
    }

    // Logica de mi aplicacion:
    $sql = "SELECT * FROM Devices";
    $result = $conn->query($sql);
    $devices = array();
    while ($device = $result->fetch_object()) {
	    $devices[] = $device;
    }

    $sql2 = "SELECT * FROM Users";
    $result2 = $conn->query($sql2);
    $users = array();
    while ($user = $result2->fetch_object()) {
	    $users[] = $user;
    }
    // Cierre de conexión o superaremos el límite
    //$conn->close();
    
    function button1($id, $conn)
    {
	    $sql = "UPDATE RA SET Action = '1' WHERE ID = '$id'";
	    $conn->query($sql);
	    $conn->close();
    }
    function button2($id, $conn)
    {
	    $sql = "UPDATE RA SET Action = '2' WHERE ID = '$id'";
	    $conn->query($sql);
	    $conn->close();
    }
    function button3($id, $conn)
    {
	    $sql = "UPDATE RA SET Action = '3' WHERE ID = '$id'";
	    $conn->query($sql);
	    $conn->close();
    }
    foreach ($users as $user):
	    $hide = ($user->IsAuthenticated == 'False') ? 'display:none' : '';
    endforeach;


    ?>



	<div class="contenedor"  style="<?php echo $hide ?>">
		<button class="botonF1" onclick="location.href='/tfg/ITService.php'">
			
			<span class="fa-rotate-right"></span>
		</button>
		

		<button class="btn botonF2" onclick="location.href='/tfg/intropage.php'">
		<span class="fa-door-open"></span>
		</button>

	</div>

	<div class="wrapper"  style="<?php echo $hide ?>">
		<!-- DEVICES-TABLE CONTAINER -->
		<div class="pricing-table group">
			<h1 class="heading"></h1>
			<!-- DEVICE -->
			<?php foreach ($devices as $device): ?>
			<!--Colores:-->
			<?php $headColor = ($device->LastStatus != 'ONLINE') ? '#E3536C' : '#3EC6E0';
	            $contentColor = ($device->LastStatus != 'ONLINE') ? '#EB6379' : '#53CFE9';
	            $lastStatusSign = ($device->LastStatus != 'ONLINE') ? (($device->LastStatus != 'RESTARTING...') ? (($device->LastStatus != 'OFFLINE') ? (($device->LastStatus != 'SUSPENDED') ? 'fa-solid fa-triangle-exclamation' : 'fa-solid fa-moon') : 'fa-solid fa-power-off') : 'fa-solid fa-rotate') : 'fa-regular fa-circle-check';
	            $pcType = ($device->PCSystemType == 'Laptop') ? 'fa-laptop' : 'fa-desktop';
	            $colorRAM = ((intval($device->AvailablePhysicalMemory) > $memoryMinLimit) && (intval($device->AvailablePhysicalMemory) < 99)) ? '#9C9C9C' : '#E3536C';
	            $borderRAM = ($colorRAM == '#E3536C') ? 'class="parpadea"' : '';
            ?>

			<div class="block personal fl">
				<h2 class="title" style="background: <?php echo $headColor; ?>">
					<?php echo $device->ID ?>
				</h2>
				<!-- CONTENT -->
				<div class="content" style="background: <?php echo $contentColor; ?>">
					<p class="price">
						<sup>
							<?php echo $device->Manufacturer ?>
						</sup>
						<br>
						<span class="<?php echo $pcType; ?>"></span>
						<br>
						<sub>
							<?php echo $device->Model ?>
						</sub>
					</p>
					<p class="hint">
						<?php echo $device->PCSystemType ?>


					</p>
				</div>
				<!-- /CONTENT -->
				<!-- FEATURES -->
				<ul class="features">
					<li><span class="fa-user-tie"></span>Owner:
						<?php echo $device->UserOwner ?>
					</li>
					<li><span class="fa-users"></span>Users Disabled:
						<?php echo $device->UsersDisabled ?>
					</li>
					<li><span class="fa-clock-rotate-left"></span>Last Seen:
						<?php echo $device->LastSeen ?>
					</li>
					<li><span class="fa-microchip"></span>Processors:
						<?php echo $device->Processors ?>
						<br>
						<span class="fa-arrow-right-long"></span>Cores:
						<?php echo $device->LogicalProcessors ?>
					</li>
					<li <?php echo $borderRAM; ?>><span class="fa-memory"
							style="color:<?php echo $colorRAM; ?>"></span>Memory:
						<?php echo $device->TotalPhysicalMemory ?> GB
						<br>
						<span class="fa-arrow-right-long"></span>Available:
						<?php echo $device->AvailablePhysicalMemory ?> MB
					</li>
					<li><span class="fa-solid fa-hard-drive"></span>Storage: C:\
						<br>
						<span class="fa-arrow-right-long"></span>Format:
						<?php echo $device->DriveFormat ?>
						<span class="fa-arrow-right-long"></span>Available:
						<?php echo $device->DriveAvailableFreeSpace ?> GB
						<span class="fa-arrow-right-long"></span>Total:
						<?php echo $device->DriveTotalSize ?> GB
					</li>
					<li><span class="fa-brands fa-microsoft"></span>
						<?php echo $device->OSName ?>
					</li>
					<li><span class="fa-circle-play"></span>Boot Up State:
						<?php echo $device->BootUpState ?>
					</li>
				</ul>
				<!-- /FEATURES -->
				<!-- PT-FOOTER -->
				<div class="pt-footer" style="background: <?php echo $contentColor; ?>">
					<p><span class="<?php echo $lastStatusSign; ?>"></span>
						<?php echo $device->LastStatus ?>
					</p>

					<?php
	            if (array_key_exists('R-' . $device->ID, $_POST)) {
		            foreach ($_POST as $name => $value) {
		            }
		            button1(substr($device->ID, 0), $conn);
	            }
	            if (array_key_exists('D-' . $device->ID, $_POST)) {
		            foreach ($_POST as $name => $value) {
		            }
		            button2(substr($device->ID, 0), $conn);
	            }
	            if (array_key_exists('E-' . $device->ID, $_POST)) {
		            foreach ($_POST as $name => $value) {
		            }
		            button3(substr($device->ID, 0), $conn);
	            }
                    ?>

					<form method="post">
						<input type="submit" name="R-<?php echo $device->ID ?>" class="buttonR" value="Restart" />
						<input type="submit" name="D-<?php echo $device->ID ?>" class="buttonC" value="Disable" />
						<input type="submit" name="E-<?php echo $device->ID ?>" class="buttonC" value="Enable" />

					</form>

				</div>
				<!-- /PT-FOOTER -->
			</div>
			<?php endforeach; ?>
			<?php //$conn->close(); ?>
			<!-- /PERSONAL -->
		</div>
		<!-- /DEVICES-TABLE -->
	</div>
	<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script><script  src="./script.js"></script>

</body>

</html>