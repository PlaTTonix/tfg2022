﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace ServicioWindows
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main()
        {
            //Inicializar DB
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = "remotemysql.com";
            builder.Port = 3306;
            builder.Database = "1drERJSalO";
            builder.UserID = "1drERJSalO";
            builder.Password = "wVDjZFTqcT";

            var connection = new MySqlConnection(builder.ToString());

            ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[]
            {
                new VVStatus(connection)
            };
            ServiceBase.Run(ServicesToRun);

           
        }
    }
}
