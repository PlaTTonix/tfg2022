﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.ServiceProcess;


namespace ServicioWindows
{
    partial class VVStatus : ServiceBase
    {
        bool flag = false;
        bool RAflag = false;
        string BatteryStatus = "Unknown";
        int attemps = 0;
        string UsersDisabled = "";
        string Users = "";
        List<string> subs4_2 = new List<string>();

        bool IDExists = false;
        bool IDExistsRA = false;
        private MySqlConnection connection;

        public VVStatus()
        {
            InitializeComponent();
        }

        public VVStatus(MySqlConnection connection)
        {
            InitializeComponent();
            this.connection = connection;
            this.CanHandlePowerEvent = true;
            //ExecuteCommand("ipconfig"); //Hay que guardaar los datos de result
        }

        private void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 

            ProcessStartInfo procStartInfo = new ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = false;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            Process proc = new Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            //string result = proc.StandardOutput.ReadToEnd();
            //Muestra en pantalla la salida del Comando
            //Console.WriteLine(result);
        }

        private string ExecuteCommandGet(string _Command)
        {
            ProcessStartInfo procStartInfo = new ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            Process proc = new Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
            //Devuelve la salida del Comando
            return result;
        }
        private void cleanRA()
        {
            try
            {

                connection.Open();
                var command = new MySqlCommand("UPDATE RA SET Action='0' WHERE ID='" + Environment.MachineName + "';", connection);
                command.ExecuteReader(); //Ejecutar la query
                connection.Close();
                RAflag = false;
                IDExistsRA = true;

            }
            catch (Exception err)
            {
                connection.Close();
                EventLog.WriteEntry("Error cleaning RA: " + err.Message, EventLogEntryType.Error);
            }

        }

        private int SelectDBRA()
        {
            int data1 = 0;
            try
            {
                var MachineID = Environment.MachineName;
                Console.WriteLine("la conexión está: " + connection.State.ToString());
                connection.Open();
                Console.WriteLine("la conexión está: " + connection.State.ToString());
                Console.WriteLine(DateTime.Now);

                if (!IDExistsRA)
                {
                    var query = new MySqlCommand("INSERT INTO `RA` (`ID`,`Action`) VALUES ('" + MachineID + "', '0');", connection);
                    query.ExecuteReader();
                }
                else
                {
                    var command = new MySqlCommand("SELECT Action FROM RA WHERE ID='" + MachineID + "';", connection);
                    var reader = command.ExecuteReader(); //Ejecutar la query

                    while (reader.Read())
                    {
                        data1 = reader.GetInt32(0);
                    }
                }

                connection.Close();
                RAflag = false;
            }
            catch (Exception err)
            {
                if (err.Message.Substring(0, 9) == "Duplicate")
                {
                    EventLog.WriteEntry("Duplicated Device detected on RA: " + err.Message, EventLogEntryType.Warning);
                    connection.Close();
                    cleanRA();
                }
                else
                {
                    EventLog.WriteEntry("Error getting action from RA DB: " + err.Message, EventLogEntryType.Error);
                }
                connection.Close();
            }
            return data1;
        }

        protected override void OnStart(string[] args)
        {
            // TODO: Add code here to start your service.

            stLapso.Start(); //Se inicia el servicio
            getTimer.Start();


        }

        protected override void OnStop()
        {
            stLapso.Stop(); //Se para el temporizador
            getTimer.Stop();
            try
            {
                var MachineID = Environment.MachineName;
                connection.Open();
                var command = new MySqlCommand("UPDATE Devices SET LastStatus='MANUALLY STOPPED' WHERE ID='" + MachineID + "';", connection);
                var reader = command.ExecuteReader(); //Ejecutar la query
                connection.Close();
            }
            catch (Exception err)
            {
                connection.Close();
                EventLog.WriteEntry("Error updating status in DB: " + err.Message, EventLogEntryType.Error);
            }

            EventLog.WriteEntry("Service Stopped!", EventLogEntryType.Warning);
        }

        protected override void OnShutdown()
        {
            stLapso.Stop(); //Se para el temporizador
            getTimer.Stop();
            try
            {
                var MachineID = Environment.MachineName;
                connection.Open();
                var command = new MySqlCommand("UPDATE Devices SET LastStatus='OFFLINE' WHERE ID='" + MachineID + "';", connection);
                var reader = command.ExecuteReader(); //Ejecutar la query
                connection.Close();
                EventLog.WriteEntry("Service Stopped by Shutdown!", EventLogEntryType.Warning);
            }
            catch (Exception err)
            {
                connection.Close();
                EventLog.WriteEntry("Error updating status in DB on Shutdown: " + err.Message, EventLogEntryType.Error);
            }


        }

        protected override bool OnPowerEvent(PowerBroadcastStatus powerStatus)
        {
            switch (powerStatus)
            {
                case PowerBroadcastStatus.BatteryLow:
                    BatteryStatus = "Low!";
                    EventLog.WriteEntry("Battery Low!", EventLogEntryType.Warning);
                    break;
                case PowerBroadcastStatus.OemEvent:
                    break;
                case PowerBroadcastStatus.PowerStatusChange:
                    //EventLog.WriteEntry("Battery Change!", EventLogEntryType.Warning);
                    //BatteryStatus = "Change of power supply!";
                    break;
                case PowerBroadcastStatus.QuerySuspend:
                    break;
                case PowerBroadcastStatus.QuerySuspendFailed:
                    break;
                case PowerBroadcastStatus.ResumeAutomatic:
                    break;
                case PowerBroadcastStatus.ResumeCritical:
                    break;
                case PowerBroadcastStatus.ResumeSuspend:
                    stLapso.Start();
                    getTimer.Start();
                    break;
                case PowerBroadcastStatus.Suspend:
                    stLapso.Stop();
                    getTimer.Stop();
                    connection.Open();
                    var query = new MySqlCommand("UPDATE Devices SET LastStatus='SUSPENDED' WHERE ID='" + Environment.MachineName + "';", connection);
                    query.ExecuteReader();
                    connection.Close();
                    break;
            }

            return base.OnPowerEvent(powerStatus);
        }

        private void stLapso_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            //Cada vez que se ejecute el servicio se hará el codigo introducido aqui
            //En nuestro caso, cada minuto.
            if (attemps > 2)
            {
                RAflag = false;
                attemps = 0;
            }
            attemps++;
            if (flag || RAflag) return; //Si el proceso se está ejecutando actualmente, no se hará nada

            DateTime utc = DateTime.UtcNow;
            DateTime own = DateTime.Now;

            try
            {
                //Console.WriteLine("Estado de conexión DB: " + connection.State.ToString());
                subs4_2.Clear();
                Users = "";
                flag = true;
                var MachineID = Environment.MachineName;
                string x64Bit = Environment.Is64BitOperatingSystem ? "True" : "False";
                string BootUpState = "Null";
                string Model = "Null";
                string DNSHostName = "Null";
                string Manufacturer = "Null";
                int NumberOfLogicalProcessors = 0;
                int NumberOfProcessors = 0;
                string PCSystemType = "0";
                string LastStatus = "ONLINE";
                string TotalPhysicalMemory = "Null";
                string RawAvailablePhysicalMemory = ExecuteCommandGet("systeminfo | find \"Available Physical\"");
                string[] subs3 = RawAvailablePhysicalMemory.Split(':');
                string AvailablePhysicalMemory = subs3[subs3.Length - 1].Substring(1);
                string[] subs3_1 = AvailablePhysicalMemory.Split('M');
                AvailablePhysicalMemory = subs3_1[0];
                string RawUserName = ExecuteCommandGet("systeminfo | find \"Owner\"");
                string[] subs = RawUserName.Split(' ');
                string UserName = subs[subs.Length - 1].ToUpper();
                string RawUsers = ExecuteCommandGet("net users");
                string[] subs4 = RawUsers.Split('-');
                string[] subs4_1 = subs4[subs4.Length - 1].Split(' ');
                //subs4_1 = subs4[subs4.Length - 1].Split('\n');

                for (int i = 0; i < subs4_1.Length - 9 ; i++)//9 para build, 4 para aqui
                {
                    if ((subs4_1[i] != "") && (subs4_1[i] != " "))
                    {
                        if ((subs4_1[i] != "DefaultAccount") && (subs4_1[i] != "WDAGUtilityAccount") && (subs4_1[i] != "\n"))
                        {

                            subs4_2.Add(subs4_1[i]);
                            //Console.WriteLine("-"+subs4_1[i]+"-");
                            /*Para arreglar esto hay que eliminar el \n de la cadena en la que haya una
                            ->
Administrator<-
->Guest<-
->
Mois‚s<-
                            */
                            //Console.WriteLine("->" + subs4_1[i]+ "<-");
                        }
                        
                    }
                }

                subs4_2.RemoveAll(s => string.IsNullOrWhiteSpace(s));
               // subs4_2.ForEach(s => Console.WriteLine(s));
                subs4_2.ForEach(s => Users += (s + ""));
                //subs4 = Users.Split('\n');subs4 = Users.Split('\t');


                string UserCode = System.Security.Principal.WindowsIdentity.GetCurrent().User.ToString();
                string IsAuthenticated = System.Security.Principal.WindowsIdentity.GetCurrent().IsAuthenticated.ToString();
               
                string DriveType = "Null";
                string DriveFormat = "Null";
                int DriveAvailableFreeSpace = 0;
                int DriveTotalFreeSpace = 0;
                int DriveTotalSize = 0;
                string RawOSName = ExecuteCommandGet("systeminfo | find \"OS Name\"");
                string[] subs1 = RawOSName.Split(':');
                string OSName = subs1[subs1.Length - 1];

                DriveInfo[] allDrives = DriveInfo.GetDrives();
                foreach (DriveInfo d in allDrives)
                {
                    if (d.Name == "C:\\")
                    {
                        //Console.WriteLine("Drive {0}", d.Name);
                        DriveType = d.DriveType.ToString();
                        if (d.IsReady == true)
                        {
                            DriveFormat = d.DriveFormat.ToString();
                            DriveAvailableFreeSpace = (int) (d.AvailableFreeSpace / 1024 / 1024 / 1024);
                            DriveTotalFreeSpace = (int) (d.TotalFreeSpace / 1024 / 1024 / 1024);
                            DriveTotalSize = (int) (d.TotalSize / 1024 / 1024 / 1024);
                        }
                    }
                }

                // create management class object
                ManagementClass mc = new ManagementClass("Win32_ComputerSystem");
                //collection to store all management objects
                ManagementObjectCollection moc = mc.GetInstances();

                if (moc.Count != 0)
                {
                    foreach (ManagementObject mo in mc.GetInstances())
                    {
                        BootUpState = mo["BootupState"].ToString();
                        Model = mo["Model"].ToString();
                        DNSHostName = mo["DNSHostName"].ToString();
                        Manufacturer = mo["Manufacturer"].ToString();
                        NumberOfLogicalProcessors = Int32.Parse(mo["NumberOfLogicalProcessors"].ToString());
                        NumberOfProcessors = Int32.Parse(mo["NumberOfProcessors"].ToString());
                        PCSystemType = mo["PCSystemType"].ToString();
                        switch (PCSystemType)
                        {
                            case "1": PCSystemType = "Desktop"; break;
                            case "2": PCSystemType = "Laptop"; break;
                            case "3": PCSystemType = "Station"; break;
                            default:
                                PCSystemType = "Unknown";
                                break;
                        }
                        TotalPhysicalMemory = (Decimal.Parse(mo["TotalPhysicalMemory"].ToString()) / 1069185365).ToString("0.##");
                        
                    }
                }

                //Queries
                connection.Open();
                
                if (IDExists)
                {
                   var query = new MySqlCommand("UPDATE Devices SET LastSeen='" + utc + " UTC', OSName='" + OSName + "', Processors='" + NumberOfProcessors + "', LogicalProcessors='" + NumberOfLogicalProcessors + "', TotalPhysicalMemory='" + TotalPhysicalMemory + "', AvailablePhysicalMemory='" + AvailablePhysicalMemory + "', UserNetworkDomain='" + Environment.UserDomainName + "', UserOwner='" + UserName + "', Users='" + Users + "', x64Bit='" + x64Bit + "', BootUpState='" + BootUpState + "', DNSHostName='" + DNSHostName + "', Manufacturer='" + Manufacturer + "', Model='" + Model + "', PCSystemType='" + PCSystemType + "', LastStatus='" + LastStatus + "', UserCode='" + UserCode + "', IsAuthenticated='" + IsAuthenticated + "', DriveType='" + DriveType + "', DriveFormat='" + DriveFormat + "', DriveAvailableFreeSpace='" + DriveAvailableFreeSpace + "', DriveTotalFreeSpace='" + DriveTotalFreeSpace + "', DriveTotalSize='" + DriveTotalSize + "', BatteryStatus='" + BatteryStatus + "' WHERE ID='" + MachineID + "';", connection);
                   query.ExecuteReader();
                }
                else
                {
                    var query = new MySqlCommand("INSERT INTO `Devices` (`ID`, `LastSeen`, `OSName`, `Processors`, `LogicalProcessors`, `TotalPhysicalMemory`, `AvailablePhysicalMemory`, `UserNetworkDomain`, `UserOwner`, `Users`, `x64Bit`, `BootUpState`, `DNSHostName`, `Manufacturer`, `Model`, `PCSystemType`, `LastStatus`, `UserCode`, `IsAuthenticated`, `UsersDisabled`, `DriveType`, `DriveFormat`, `DriveAvailableFreeSpace`, `DriveTotalFreeSpace`, `DriveTotalSize`, `BatteryStatus`) VALUES ('" + MachineID + "', '" + utc + " UTC', '" + OSName + "', '" + NumberOfProcessors + "', '" + NumberOfLogicalProcessors + "', '" + TotalPhysicalMemory + "', '" + AvailablePhysicalMemory + "', '" + Environment.UserDomainName + "', '" + UserName + "', '" + Users + "', '" + x64Bit + "', '" + BootUpState + "', '" + DNSHostName + "', '" + Manufacturer + "', '" + Model + "', '" + PCSystemType + "', '" + LastStatus + "', '" + UserCode + "', '" + IsAuthenticated + "', 'No', '" + DriveType + "', '" + DriveFormat + "', '" + DriveAvailableFreeSpace + "', '" + DriveTotalFreeSpace + "', '" + DriveTotalSize + "', '" + BatteryStatus + "');", connection);
                    query.ExecuteReader();

                }

                //EventLog.WriteEntry("Device Info Sent!", EventLogEntryType.Information);

                //BETA
                if (ConfigurationSettings.AppSettings["EnableEventTxt"].ToString() == "true")
                {
                    //Para que fuera automatico hay que averiguar el idioma de la carpeta no siempre sera en ingles o español...
                    string stDestino = ConfigurationSettings.AppSettings["EventTxt"].ToString();
                    string fileEvent = "VVEvents.txt";

                    if (!File.Exists(stDestino + fileEvent))
                    {
                        using (StreamWriter sw = File.CreateText(stDestino + fileEvent))
                        {
                            sw.WriteLine("Time: " + utc + " UTC - " + own + " Owner TimeZone");
                            sw.WriteLine("Estado de conexión DB: " + connection.State.ToString());
                            sw.WriteLine("--- ** ---");
                        }
                    }
                    else
                    {
                        using (StreamWriter sw = File.AppendText(stDestino + fileEvent))
                        {
                            sw.WriteLine("Time: " + utc + " UTC - " + own + " Owner TimeZone");
                            sw.WriteLine("Estado de conexión DB: " + connection.State.ToString());
                            sw.WriteLine("--- ** ---");
                        }
                    }
                }

                connection.Close();
                //Console.WriteLine("Estado de conexión DB: " + connection.State.ToString());
            }
            catch (Exception err) {
                
                if (err.Message.Substring(0, 9) == "Duplicate")
                {
                    IDExists = true;
                    EventLog.WriteEntry("Duplicated Device detected: " + err.Message + "\nUpdating instead...Please wait", EventLogEntryType.Warning);
                }
                else
                {

                    EventLog.WriteEntry("Synchronization issue: " + err.Message, EventLogEntryType.Error);
                    
                    //BETA
                    if (ConfigurationSettings.AppSettings["EnableLogs"].ToString() == "true")
                    {
                        //Para que fuera automatico hay que averiguar el idioma de la carpet no siempre sera Users...
                        string stDestino = ConfigurationSettings.AppSettings["LogsDir"].ToString() + Environment.UserName + "\\";
                        string fileEvent = "VVErrorLog.txt";
                        if (!File.Exists(stDestino + fileEvent))
                        {
                            using (StreamWriter sw = File.CreateText(stDestino + fileEvent))
                            {
                                sw.WriteLine("TimeDate: " + utc + " UTC - " + own + " Owner TimeZone");
                                sw.WriteLine("Estado de conexión DB: " + connection.State.ToString());
                                sw.WriteLine(err.Message.ToString());
                                sw.WriteLine("--- ** ---");
                            }
                        }
                        else
                        {
                            using (StreamWriter sw = File.AppendText(stDestino + fileEvent))
                            {
                                sw.WriteLine("TimeDate: " + utc + " UTC - " + own + " Owner TimeZone");
                                sw.WriteLine("Estado de conexión DB: " + connection.State.ToString());
                                sw.WriteLine(err.Message.ToString());
                                sw.WriteLine("--- ** ---");
                            }
                        }
                    }

                }

                connection.Close();
            }

            flag = false;
        }

        private void RestartPC() {

            stLapso.Stop(); //Se para el temporizador
            getTimer.Stop();
            try
            {
                var MachineID = Environment.MachineName;
                connection.Open();
                var command = new MySqlCommand("UPDATE Devices SET LastStatus='RESTARTING...' WHERE ID='" + MachineID + "';", connection);
                var reader = command.ExecuteReader(); //Ejecutar la query
                connection.Close();
                EventLog.WriteEntry("Service Stopped by Restart!", EventLogEntryType.Warning);
            }
            catch (Exception err)
            {
                connection.Close();
                EventLog.WriteEntry("Error updating status in DB on Restart: " + err.Message, EventLogEntryType.Error);
            }

            ExecuteCommand("shutdown /r /t 10 /c \"IT - Remote Action Received - You have about 10 seconds to save all your work.\"");

        }

        private void DisableUser(string _User)
        {
            IDExistsRA = false;
            try
            {
                var MachineID = Environment.MachineName;
                connection.Open();
                var command = new MySqlCommand("UPDATE Devices SET UsersDisabled='" + _User + "\n' WHERE ID='" + MachineID + "';", connection);
                var reader = command.ExecuteReader(); //Ejecutar la query
                connection.Close();
                EventLog.WriteEntry("User " + _User + " disabled!", EventLogEntryType.Warning);
            }
            catch (Exception err)
            {
                connection.Close();
                EventLog.WriteEntry("Error updating status in DB on Recover: " + err.Message, EventLogEntryType.Error);
            }

            ExecuteCommand("net user " + _User + " /active:no");
            cleanRA();

        }

        private void DisableAllUsers()
        {
            IDExistsRA = false;
            try
            {
                var MachineID = Environment.MachineName;
                connection.Open();
                var command = new MySqlCommand("UPDATE Devices SET UsersDisabled='Yes' WHERE ID='" + MachineID + "';", connection);
                var reader = command.ExecuteReader(); //Ejecutar la query
                connection.Close();
                EventLog.WriteEntry("Users disabled!", EventLogEntryType.Warning);
            }
            catch (Exception err)
            {
                connection.Close();
                EventLog.WriteEntry("Error updating status in DB on Disabling: " + err.Message, EventLogEntryType.Error);
            }

            EventLog.WriteEntry("Users disabled: " + Users, EventLogEntryType.Warning);

            // subs4_2.ForEach(s => Console.WriteLine(s));

            subs4_2.ForEach(s => ExecuteCommand("net user " + s + " /active:no"));
            
           
            cleanRA();

        }

        private void EnableAllUsers()
        {
            IDExistsRA = false;
            try
            {
                var MachineID = Environment.MachineName;
                connection.Open();
                var command = new MySqlCommand("UPDATE Devices SET UsersDisabled='No' WHERE ID='" + MachineID + "';", connection);
                var reader = command.ExecuteReader(); //Ejecutar la query
                connection.Close();
                EventLog.WriteEntry("Users enabled!", EventLogEntryType.Warning);
            }
            catch (Exception err)
            {
                connection.Close();
                EventLog.WriteEntry("Error updating status in DB on enabling users: " + err.Message, EventLogEntryType.Error);
            }

            EventLog.WriteEntry("Users Enabled: " + Users, EventLogEntryType.Warning);

            // subs4_2.ForEach(s => Console.WriteLine(s));

            subs4_2.ForEach(s => ExecuteCommand("net user " + s + " /active:yes"));

            cleanRA();

        }

        private void getTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            //EventLog.WriteEntry("Flag: " + flag, EventLogEntryType.Warning);

            if (!flag || RAflag)
            {
                RAflag = true;
                switch (SelectDBRA())
                {
                    case 1:
                        RestartPC();
                        break;

                    case 2:
                        DisableAllUsers();
                        break;

                    case 3:
                        EnableAllUsers();
                        break;

                    default: break;
                }
                /*
                try
                {
                    connection.Open();
                    var command = new MySqlCommand("UPDATE RA SET Action='0' WHERE ID='" + Environment.MachineName + "';", connection);
                    command.ExecuteReader(); //Ejecutar la query
                    connection.Close();
                }
                catch (Exception err)
                {
                    connection.Close();
                    EventLog.WriteEntry("Error updating status in DB on getTimer_Elapsed: " + err.Message, EventLogEntryType.Error);
                }*/
                
            }         
            
        }
    }
}
